<?php

namespace Test2Namespace;

class Test2ClassDynamic
{}
