<?php

namespace TestNamespace;

class TestClassDynamic
{}
