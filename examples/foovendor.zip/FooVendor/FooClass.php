<?php

namespace FooVendor;

class FooClass
{
}
