<?php

namespace Plugins\FooPlugin;

class FooPlugin
{
}
