<?php

namespace Plugins\BarPlugin;

class BarPlugin
{
}
